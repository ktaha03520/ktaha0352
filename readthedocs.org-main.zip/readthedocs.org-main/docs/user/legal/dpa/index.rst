Data Processing Addendum (DPA)
==============================

.. toctree::
    :hidden:

    subprocessors

Read the Docs can execute a DPA with any customer that receives data from the EU.
You can complete this by reviewing and accepting the following pre-signed agreement:

`Review the Read the Docs Data Processing Addendum <https://readthedocs.eversign.com/embedded/fa9e5a24917c4440a1770251102a044e>`_

.. seealso::
   :doc:`Read the Docs sub-processor list <subprocessors>`
      An up-to-date list of the sub-processors we use for hosting services.
