"""App initialization."""
